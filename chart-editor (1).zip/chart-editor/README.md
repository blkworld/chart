# Chart Editor

Editor candlestick/chart berbasis SVG. Client-side only: Vite + vanilla JS + Tailwind. Tema light/dark.

## Dev (Codespaces atau lokal)

```bash
npm install
npm run split -- original.html   # sekali saja
npm run dev
```

## Struktur

- `index.html` - markup (hasil split)
- `src/main.js` - logika asli (hasil split, tidak diubah)
- `src/styles.css` - design tokens + komponen (edit tampilan di sini)
- `src/theme.js` - toggle light/dark

## Deploy

Push ke GitHub, import di Vercel (preset Vite otomatis).
