/** @type {import('tailwindcss').Config} */
// Warna utility yang dipakai markup asli (zinc/blue/emerald) dipetakan ke token tema,
// sehingga light/dark otomatis tanpa mengubah markup.
export default {
  content: ['./index.html', './src/**/*.js'],
  theme: {
    extend: {
      fontFamily: { sans: ['Geist', 'Inter', 'system-ui', 'sans-serif'] },
      colors: {
        zinc: {
          50: 'var(--surface-2)',
          500: 'var(--text-muted)',
          700: 'var(--text-2)',
          900: 'var(--text)'
        },
        blue: { 600: 'var(--accent)', 700: 'var(--accent-hover)' },
        emerald: { 500: 'var(--success)' }
      }
    }
  },
  plugins: []
};
