// Usage: node tools/split.mjs original.html
// Memecah HTML asli menjadi index.html (markup) + src/main.js (logika, TIDAK diubah).
// CSS tidak dibuat ulang: src/styles.css (desain baru) dan src/theme.js sudah ada di repo.
import fs from 'node:fs';
import path from 'node:path';

const input = process.argv[2];
if (!input) {
  console.error('Usage: node tools/split.mjs original.html');
  process.exit(1);
}
const html = fs.readFileSync(input, 'utf8');

// JS inline = <script> tanpa src, ambil yang terakhir
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
if (!scripts.length) throw new Error('inline <script> tidak ditemukan');
const jsMatch = scripts[scripts.length - 1];
let js = jsMatch[1].trim();

const bodyMatch = html.match(/<body([^>]*)>([\s\S]*?)<\/body>/);
if (!bodyMatch) throw new Error('<body> tidak ditemukan');
const bodyAttrs = bodyMatch[1];
const bodyInner = bodyMatch[2].replace(jsMatch[0], '').trimEnd();

// Ekspos fungsi ke window agar onclick/oninput di markup tetap jalan di ES module
const names = [...new Set([...js.matchAll(/^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/gm)].map(m => m[1]))];
js =
  "import './styles.css';\nimport './theme.js';\n\n" +
  js +
  '\n\n// Handler inline di index.html membutuhkan scope global.\n' +
  'Object.assign(window, {\n  ' + names.join(',\n  ') + '\n});\n';

const title = (html.match(/<title>([\s\S]*?)<\/title>/) || [, 'Chart Editor'])[1];
const themeInit =
  "(function(){try{var t=localStorage.getItem('theme');if(!t){t=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}document.documentElement.dataset.theme=t}catch(e){document.documentElement.dataset.theme='light'}})();";

const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <script>${themeInit}</script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body${bodyAttrs}>
${bodyInner}

    <script type="module" src="/src/main.js"></script>
</body>
</html>
`;

fs.mkdirSync('src', { recursive: true });
fs.writeFileSync('index.html', indexHtml);
fs.writeFileSync(path.join('src', 'main.js'), js);
console.log(`OK: index.html + src/main.js (${names.length} fungsi diekspos ke window)`);
