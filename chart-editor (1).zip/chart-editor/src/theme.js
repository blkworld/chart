const KEY = 'theme';
const root = document.documentElement;

const SUN =
  '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>';
const MOON =
  '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>';

function stored() {
  try { return localStorage.getItem(KEY); } catch (e) { return null; }
}

function systemTheme() {
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function apply(theme, persist) {
  root.dataset.theme = theme;
  const btn = document.getElementById('btn-theme');
  if (btn) {
    btn.innerHTML = theme === 'dark' ? SUN : MOON;
    btn.title = theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme';
    btn.setAttribute('aria-label', btn.title);
  }
  if (persist) {
    try { localStorage.setItem(KEY, theme); } catch (e) { /* storage blocked */ }
  }
}

function mountToggle() {
  const anchor = document.getElementById('btn-copy');
  if (!anchor || document.getElementById('btn-theme')) return;

  const group = document.createElement('div');
  group.className = 'icon-group';

  const btn = document.createElement('button');
  btn.id = 'btn-theme';
  btn.type = 'button';
  btn.className = 'icon-btn';
  btn.addEventListener('click', function () {
    apply(root.dataset.theme === 'dark' ? 'light' : 'dark', true);
  });

  group.appendChild(btn);
  anchor.parentElement.insertBefore(group, anchor);
}

mountToggle();
apply(root.dataset.theme || stored() || systemTheme(), false);

// Ikuti pengaturan sistem selama user belum memilih manual.
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function (e) {
  if (!stored()) apply(e.matches ? 'dark' : 'light', false);
});
